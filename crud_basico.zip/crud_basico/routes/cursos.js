const express = require("express"); 
const router = express.Router(); 
const { Curso } = require("../models"); 

// Listar categorias 
router.get("/",  async (req, res) => { 
  const curso = await Curso.findAll(); 
  res.render("base", { 
    title: "Cursos", 
    view: "cursos/show", 
    cursos, 
  }); 
}); 

// Formulário para adicionar categoria 
router.get("/add",  (req, res) => { 
  res.render("base", { 
    title: "Add Curso", 
    view: "cursos/add", 
  }); 

}); 

// Adicionar nova categoria 
router.post("/add",  async (req, res) => { 
  await Curso.create({ nome: req.body.nome }); 
  res.redirect("/cursos"); 
}); 

// Formulário para editar categoria 
router.get("/edit/:id",  async (req, res) => { 
  const curso = await Curso.findByPk(req.params.id); 
  res.render("base", { 
    title: "Editar Curso", 
    view: "cursos/edit", 
    curso, 
  }); 
}); 

// Atualizar categoria 
router.post("/edit/:id",  async (req, res) => { 
  await Curso.update( 
    { nome: req.body.nome }, 
    { 
      where: { id: req.params.id }, 
    } 
  ); 
  res.redirect("/cursos"); 
}); 

// Deletar categoria 
router.post("/delete/:id",  async (req, res) => { 
  await Curso.destroy({ where: { id: req.params.id } }); 
  res.redirect("/curso"); 
}); 

 

module.exports = router; 

 