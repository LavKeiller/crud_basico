const express = require('express');
const router = express.Router();
const { Professor } = require('../models');

// Listar professores
router.get('/', async (req, res) => {
  const professores = await Professor.findAll();
  res.render("base", {
    title: "Listar Professores",
    view: "professor/show",
    professores,
  });
});

// Formulário para adicionar
router.get('/add', (req, res) => {
  res.render("base", {
    title: "Adicionar Professor",
    view: "professor/add",
  });
});

// Adicionar novo professor
router.post('/add', async (req, res) => {
  await Professor.create({
    codigo: req.body.codigo,
    // nome: req.body.nome // descomente se quiser usar nome
  });
  res.redirect('/professor');
});

// Formulário para editar
router.get('/edit/:id', async (req, res) => {
  const professor = await Professor.findByPk(req.params.id);
  res.render("base", {
    title: "Editar Professor",
    view: "professor/edit",
    professor
  });
});

// Atualizar professor
router.post('/edit/:id', async (req, res) => {
  await Professor.update(
    {
      codigo: req.body.codigo,
      // nome: req.body.nome // descomente se quiser usar nome
    },
    {
      where: { id: req.params.id }
    }
  );
  res.redirect('/professor');
});

// Deletar professor
router.post("/delete/:id", async (req, res) => {
  await Professor.destroy({ where: { id: req.params.id } });
  res.redirect("/professor");
});


module.exports = router;
