module.exports = (sequelize, DataTypes) => {
  const Professor = sequelize.define('Professor', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
    },
    codigo: {
      type: DataTypes.INTEGER,
      allowNull: false
    }
   
  }, {
    tableName: 'professores', //  nome exato da tabela
    timestamps: true // ou false se você não quiser createdAt/updatedAt
  });

  Professor.associate = (models) => { 
        Professor.hasMany(models.Materia, { 
          foreignKey: "professorId", 
          as: "materias", 
        }); 
      };

  return Professor;
};