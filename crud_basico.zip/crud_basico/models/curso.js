module.exports = (sequelize, DataTypes) => {
    
    const Curso = sequelize.define("Curso", {
      nome: {
        type: DataTypes.STRING,
        allowNull: false,
      },
    });
  
    Curso.associate = (models) => { 
            Categoria.hasMany(models.Aluno, { 
              foreignKey: "cursoId", 
              as: "aluno", 
            }); 
          };
  
    return Curso;
  };