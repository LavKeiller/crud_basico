module.exports = (sequelize, DataTypes) => {
  const Aluno = sequelize.define("Aluno", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false
    },
    RM: {
      type: DataTypes.INTEGER,
      allowNull: false,
    }
  });

  Aluno.associate = (models) => {
    Aluno.belongsTo(models.Curso, {
      foreignKey: "cursoId",
      as: "Curso",
    });
  };

  return Aluno;
};
