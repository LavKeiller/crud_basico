module.exports = (sequelize, DataTypes) => {
    const Materia = sequelize.define("Materia", {
      nome: {
        type: DataTypes.STRING,
        allowNull: false,
      },
    });
  
    Materia.associate = (models) => {
      // O alias deve ser 'Categoria' para corresponder ao alias na consulta
      Materia.belongsTo(models.Professor, {
        foreignKey: "professorId",
        as: "Professor", // Use o alias consistente com as consultas
      });
    };
  
    return Materia;
  };
  